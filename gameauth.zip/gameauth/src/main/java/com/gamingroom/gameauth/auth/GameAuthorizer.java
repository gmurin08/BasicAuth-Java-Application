package com.gamingroom.gameauth.auth;

import io.dropwizard.auth.Authorizer;

public class GameAuthorizer implements Authorizer<GameUser> 
{
    @Override
    public boolean authorize(GameUser user, String role) {
    	
        /*
         * FIXED: Finish the authorize method based on BasicAuth Security Example
         * 
         * This allows us to verify that the user is accessing their own information
         * AND that they are authorized to access said functionality based on their role.
         */
    	
    	return user.getRoles() != null && user.getRoles().contains(role);
    	   
    	
    }
}